


import boto3

aws_mag_con_root=boto3.session.Session(profile_name="user30")
#aws_mag_con_root=boto3.session.Session(profile_name="ec2_developer")


## using resource
iam_con_re=aws_mag_con_root.resource(service_name='iam',region_name="ap-southeast-2")
#Listiing iam users with resource object:
print(dir(iam_con_re))
for each_user in iam_con_re.users.all():
    print(each_user.name)



############# using client
iam_con_cli=aws_mag_con_root.client(service_name='iam',region_name="ap-southeast-2")
#Listing iam users with client object:

for each in iam_con_cli.list_users()['Users']:
   print(each['UserName'])




