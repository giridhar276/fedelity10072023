


import boto3

AWS_REGION = "ap-south-1"


session=boto3.session.Session(profile_name="default")
client = session.client("s3", region_name=AWS_REGION)
bucket_name = "giri09062023new1"
location = {'LocationConstraint': AWS_REGION}

response = client.create_bucket(Bucket=bucket_name, CreateBucketConfiguration=location)

print("Amazon S3 bucket has been created")



## display buckets
import boto3

AWS_REGION = "ap-south-1"

session=boto3.session.Session(profile_name="default")
client = session.client("s3", region_name=AWS_REGION)

response = client.list_buckets()

print("Listing Amazon S3 Buckets:")

for bucket in response['Buckets']:
    print(f"-- {bucket['Name']}")
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
# delete buckets
import boto3

AWS_REGION = "ap-south-1"

session=boto3.session.Session(profile_name="default")
client = session.client("s3", region_name=AWS_REGION)

bucket_name = "giri09062023new"

client.delete_bucket(Bucket=bucket_name)

print("Amazon S3 Bucket has been deleted")    











#
import pathlib
import boto3
from glob import glob



AWS_REGION = "ap-south-1"
S3_BUCKET_NAME = "giri09062023new"

session=boto3.session.Session(profile_name="default")
s3_client = session.client("s3", region_name=AWS_REGION)


def upload_file(file_name, bucket, object_name=None, args=None):
    if object_name is None:
        object_name = file_name

    s3_client.upload_file(file_name, bucket, object_name, ExtraArgs=args)
    print(f"'{file_name}' has been uploaded to '{S3_BUCKET_NAME}'")
    
    s3_client.upload_file(file_name, bucket, object_name, ExtraArgs=args)
    print(f"'{file_name}' has been uploaded to '{S3_BUCKET_NAME}'")


files = glob("*.txt")
print(files)

for file in files:
    upload_file(file, S3_BUCKET_NAME)    
    
    
    
    
    
    
import pathlib
import boto3
from glob import glob
import os


AWS_REGION = "ap-south-1"
S3_BUCKET_NAME = "giri09062023new"

session=boto3.session.Session(profile_name="default")
s3_client = session.client("s3", region_name=AWS_REGION)


def upload_file(file_name, bucket, object_name=None, args=None):
    if object_name is None:
        object_name = file_name

    s3_client.upload_file(file_name, bucket, object_name, ExtraArgs=args)
    print(f"'{file_name}' has been uploaded to '{S3_BUCKET_NAME}'")
    
    s3_client.upload_file(file_name, bucket, object_name, ExtraArgs=args)
    print(f"'{file_name}' has been uploaded to '{S3_BUCKET_NAME}'")

os.chdir(r'D:\trainings\epsilon1\awscloud')
files = os.listdir()
print(files)

for file in files:
    upload_file(file, S3_BUCKET_NAME)    
    
    
    