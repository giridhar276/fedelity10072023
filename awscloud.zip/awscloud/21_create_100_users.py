


#!/bin/python
import boto3,sys
while True:
  session=boto3.session.Session(profile_name="user30")
  iam_re=session.resource(service_name="iam")
  for each in range(701,710):
   try:
     iam_re.create_user(UserName="user"+str(each))
   except Exception as err:
       print(err)
      
