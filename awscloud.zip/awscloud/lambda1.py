import boto3

def lambda_handler(event, context):
    session = boto3.session.Session(aws_access_key_id = "AKIAWFMZEMEDVE3QJGNL" , aws_secret_access_key = "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")
    ec2_con = session.resource(service_name = "ec2" , region_name = "ap-south-1")
    for each in ec2_con.instances.all():
        print(each.id)


def lambda_handler(event, context):
    #session = boto3.session.Session(aws_access_key_id = "AKIAWFMZEMEDVE3QJGNL" , aws_secret_access_key = "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")
    #ec2_con = session.resource(service_name = "ec2" , region_name = "ap-south-1")
    ec2_con = boto3.resource("ec2","ap-south-1")
    for each in ec2_con.instances.all():
        print("testing")
        print(each.id)
        
import json

import boto3
def lambda_handler(event, context):
    
    s3_con = boto3.resource("s3","ap-south-1")
    for each in s3_con.buckets.all():
        print(each.name)
        


# start
import json
import boto3

def lambda_handler(event, context):
    ec2_con_re = boto3.resource(service_name = 'ec2' , region_name = "ap-south-1")
    for each in ec2_con_re.instances.all():
        print(each.start())
    

#stop
import json
import boto3

def lambda_handler(event, context):
    ec2_con_re = boto3.resource(service_name = 'ec2' , region_name = "ap-south-1")
    for each in ec2_con_re.instances.all():
        print(each.stop())
    
#0 8 ? * MON-FRI *





#mail notification


import json
import boto3

def lambda_handler(event, context):
    ec2_con = boto3.resource("ec2","ap-south-1")
    sns_client = boto3.client('sns','ap-south-1')
    my_ins = ec2_con.Instance('i-03313c547e8afe030')
    print(my_ins.state['Name'])
    
    #sns_client.publish(TargetArn ='arn:aws:sns:ap-south-1:423912300807:status_of_ec2', Message= my_ins.state['Name'] )
    sns_client.publish(TargetArn ='arn:aws:sns:ap-south-1:423912300807:status_of_ec2', Message= "Instance is stopped" )