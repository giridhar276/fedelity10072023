


import boto3,sys
while True:
  session=boto3.session.Session(profile_name="user30")
  iam_re=session.resource(service_name="iam")
  for each in range(701,703):
   try:
     iam_re.create_user(UserName="labuser"+str(each))
   except Exception as err:
       print(err)
      