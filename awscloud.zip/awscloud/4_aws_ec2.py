
import boto3


aws_mag_con_root=boto3.session.Session(profile_name="default")
ec2 = aws_mag_con_root.resource('ec2')

print(ec2)




instances = ec2.create_instances(
        ImageId="ami-049a62eb90480f276",
        MinCount=1,
        MaxCount=1,
        InstanceType="t2.micro"
    )


print(instances)
#print(instances["Instances"][0]["InstanceId"])
