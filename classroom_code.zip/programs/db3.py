

import pymysql
try:
    #step1
    with pymysql.connect(host='127.0.0.1',port=3306,user='root',password='Password@1') as conn:
        
        if conn:
            cursor = conn.cursor()
            #step2
            query = "select * from adultinfo.adult"
            #step3
            cursor.execute(query)
            #step4
            for record in cursor.fetchall():
                worktype = record[0]
                education = record[1]
                occupation = record[2]
                print(worktype,education,occupation)
                print("------")
            #step5
            #conn.close()
        else:
            print('connection not successful.. something went wrong')
except pymysql.err.DataError as err:
    print(err)
except pymysql.err.DatabaseError as err:
    print(err)
except pymysql.err.OperationalError as err:
    print(err)    
except (pymysql.err.IntegrityError,pymysql.err.InternalError) as err:
    print(err)
except Exception as err:
    print(err)