class Employee:
    # constructor
    # constructor in python starts with __init__
    # constructor is invoked automatically when the object is created
    def __init__(self,name = 'default',address = 'default'):
        self.name= name
        self.address = address
        
    def displayEmployee(self):
        print("Employee name :",self.name)
        print("Address       :",self.address)

#object creation
emp1 = Employee('rita','hyd')
emp1.displayEmployee()

emp2 = Employee('singh','mumbai')
emp2.displayEmployee()

emp3 = Employee('rao','bangalore')
emp3.displayEmployee()

emp4 = Employee('smita','delhi')
emp4.displayEmployee()

emp5 = Employee()
emp5.displayEmployee()
