# this is the single line comment



print(10)
print(10,20,320,30)
print("unix","java","spark")
print("Value is",10)

val = 10
print("value is ",val)
'''
lang = 'python'
print('I love',lang)
'''


"""
these lines
are
commented  - multi line comment
"""



aname ='python programming'
bname = "java programming"
cname = """scala programming"""

print('I love',aname)





