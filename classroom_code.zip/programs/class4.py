

import csv

class FileOperation:
    def __init__(self,file):
        self.file = file
    def displayOutput(self):
            self.fobj = open(self.file,'r')
            self.reader = csv.reader(self.fobj)
            for record in self.reader:
                print(record)
        

file1 = FileOperation('adult.csv')
file1.displayOutput()