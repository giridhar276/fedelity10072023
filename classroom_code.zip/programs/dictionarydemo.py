book = {"chap1":10 ,"chap2":20,"chap3":30}
print(book)
# add new key,value to the dictionary
#dictionary[newkey] = value
book['chap4'] = 40
book['chap5'] = 50
print(book)
# display individual values
print(book['chap1'])
# display keys
print(book.keys())

for key in book.keys():
    print(key)

for key in book:
    print(key)

# displaay values
print(book.values())

for value in book.values():
    print(value)
    
    
# dispplay key,value from dictionary
print(book.items())
print(book)
for key,value in book.items():
    print(key,value)
    
# check for existence
if 'chap133' in book:
    print('key exists..!!')
else:
    print('key doesnt exist')
    
# check for existence
if 20 in book.values():
    print('value exists..!!')
else:
    print('value doesnt exist')
    
    
# remove key-value from dictionary
book.pop('chap2')
print('After pop', book)

# remove one key-value
book.popitem()
print(book)


print(book['chap100'])
# if key is not existing... will dipaly keyError
# if key is existing ... will display the value
print(book.get('chap100'))




# []
name = 'python'
name[0]

alist = [10,20,30]
alist[0]

book = {"chap1":10}
print(book['chap1'])

atup = (40,50,60)
atup[1]

print(name.upper())
alist.append(50)
book.keys()






