
try:
    with open('languages198.txt','r') as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
except FileNotFoundError as err:
    print("system generated error :",err)
    print("error found")
except KeyError as err:
    print('Key is not found')
except ValueError as err:
    print('Invalid operation')
except (TypeError,IndexError) as err:
    print('Error found')
else:
    print('If error is not found in try block')
    print('this gets executed')
finally:
    print('this block will be executed all the times')
    
print('regular code')
    


    
    