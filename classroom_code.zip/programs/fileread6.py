



with open('adult2.csv','r') as fr:
    with open('adult1.csv','a') as fa:
        for line in fr:
            fa.write(line)