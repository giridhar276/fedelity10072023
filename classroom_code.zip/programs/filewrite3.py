
# context manager
# if line starts with keyword with ... we call it as context manager
# file will be closed automatically

# pythonic way


with open('languages111.txt','a')  as fw:
    fw.write('unix\n')


