alist = [10,20,30]
alist[0] =1000
print('After replacing :',alist)


# tuple is immutable
# elements inside tuple cannot be modified DIRECTLY
atup = (30,40,40)
#atup[0] = 3000
print('After replacing :',atup)

# typecasting = converting from tuple to list
# converting tuple to list
info = list(atup)
# changes to the list
info[0] = 3000
# recverting back to tuple
atup = tuple(info)
print(atup)

