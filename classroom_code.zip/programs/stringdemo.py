
name = 'python programming'
print(name)
#string slicing
# string[start:stop:incremental]
print(name[0])
print(name[1])
print(name[0:4:1])
print(name[7:10])
print(name[7:10:1])
print(name[13:19])
print(name[13:19:1])
print(name[0:18])
print(name[:])
print(name[0:18:2])
print(name[1:18:2])
print(name[::]) # python programming
print(name[::2]) #print(name[0:18:2])
print(name[-1])
print(name[-2])
print(name[-4:-1])
print(name[::-1])
print(name[13:7:-1])


name = 'python programming'
print(name.isalpha())
print(name.capitalize())
print(name.title())
print(name.upper())
print("original string :",name)
print(name.lower())
print(name.count('p'))
print(name.count('abc'))
print(name.count('prog'))
print(name.replace('python','scala'))
print("original string :",name)
print(name.startswith(('r')))
print(name.startswith(('p')))
print(name.endswith('q'))
print(len(name))

aname = ' python  '
print(len(aname))
print(len(aname.lstrip()))
print(len(aname.rstrip()))
print(len(aname.strip())) # remove whitespaces at both the ends

string = "I love {} and {}"
print(string.format('python','unix'))
print(string.format(1,2))

string = "I love {1} and {0}"
print(string.format('python','unix'))
print(string.format(1,2))

astr = "python,java,unix,oracle"
output = astr.split(",")
print(output)






















