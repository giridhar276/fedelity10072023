


import json

with open('sample4.json','r') as fr:
    # converting file object to json understandable format
    data = json.load(fr)
    for item in data['people']:
        itemlist = list(item.values())
        #print(itemlist)
        itemlist[3] = str(itemlist[3])
        line = ",".join(itemlist)
        print(line)
        
        
