alist = [10,20,30,2,45,16,9,10,10,10,10]
# add single object
alist.append(50)
print('After appending :',alist)
# adding multiple values
alist.extend([93,19,7])
print('After extending :',alist)
# list.insert(index,value)
alist.insert(1,200)
print('After inserting :',alist)
#list.pop(index) - value at that index will be removed
alist.pop(1)
print('After pop:',alist)
# list.remove(value)
alist.remove(10) # will remove the first occurence of the value
print('After removing :',alist)
# remove all the occurences 
#          range(0,5)
for val in range(0,alist.count(10)):
    alist.remove(10)
print(alist)

if 10000 in alist:
    alist.remove(10000)
else:
    print('value doesnt exist')
    
name = 'python programming'
if 'prog' in name:
    print('substring exists')

#sort the values
alist.sort()
print('After sorting :',alist)
# descending order
alist.sort(reverse = True)
print('After sorting :',alist)
# reversing
alist.reverse()
print('After reversing:',alist)
