import pdb
pdb.set_trace()


import csv

class FileOperation:
    def __init__(self,file):
        self.file = file
    def displayOutput(self):
            self.fobj = open(self.file,'r')
            self.reader = csv.reader(self.fobj)
            for record in self.reader:
                print(record)
        

# if this program is executed directly ... this condition will be always True
# if this program is imported to other program... this condition will be False
if __name__ == "__main__":
    file1 = FileOperation('adult.csv')
    file1.displayOutput()
    
    
    
    