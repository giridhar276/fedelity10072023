


import requests
import json

username = "giridhar276"
password = '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'

server = 'https://api.github.com/'

# just like select query
data = requests.get(server,auth=(username,password))

if data.status_code == 200:
    #converting the string to the dictionary
    jdata = json.loads(data.text)
    for key,value in jdata.items():
        print(key.ljust(20),value)