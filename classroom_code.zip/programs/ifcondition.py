# simple if statement
a = 10
b = 2
if a > b :
    print('A is greater than B')
    print('inside if')
    print('still inside if')
    print('inside if')
    
# if else block
a = 10
b = 2
if a > b :
    print('A is greater than B')
    print('inside if')
    print('still inside if')
    print('inside if')
else :
    print('B is greater than A')
    print('inside else')
    print('still inside else')

name = 'python'
if name.isupper():
    print('string is upper')
else:
    print('string is lower')
    
    
if name.startswith('p'):
    print('its python programming')



## if-elif-elif-elif...else

lang = 'python'
if lang == 'python':
    print('its python')
elif lang == 'java':
    print('its java')
elif lang =='oracle':
    print('ts oracle')
else:
    print('its some other language')




# range(start,stop,step)
for val in range(1,11):
    print(val)
    
for val in range(11,0,-1):
    print(val)
    
for val in range(1,11,2):
    print(val)
    
    
    
name = 'python'
for char in name:
    print(char)

alist = [10,20,30]
for val in alist:
    print(val)
    





    
    
    
    
    
    
    


