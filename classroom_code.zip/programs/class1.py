

class Employee:
    def displayEmployee(self):
        print('Employee name :',"rita")
        print('Address   :','hyd')
        
        
emp1 = Employee()
emp1.displayEmployee()
    

emp2 = Employee()
emp2.displayEmployee()