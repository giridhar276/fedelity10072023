from openpyxl import Workbook
wb = Workbook()
ws = wb.active
import time,pymysql
#import 
try:
    filename = time.strftime("%d_%b_%Y.xlsx")
    print(filename)
    #step1
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='Password@1') 
    if conn:
        cursor = conn.cursor()
        #step2
        query = "select * from adultinfo.adult"
        #step3
        cursor.execute(query)
        #step4
        for record in cursor.fetchall():
            worktype = record[0]
            education = record[1]
            occupation = record[2]
            #print(worktype,education,occupation)
            ws.append([worktype,education,occupation])
            #print("------")
        #step5
        conn.close()
        wb.save(filename)
    else:
        print('connection not successful.. something went wrong')
except pymysql.err.DataError as err:
    print(err)
except pymysql.err.DatabaseError as err:
    print(err)
except pymysql.err.OperationalError as err:
    print(err)    
except (pymysql.err.IntegrityError,pymysql.err.InternalError) as err:
    print(err)
except Exception as err:
    print(err)