# fixed arguments
def display(a,b):
    print(a,b)

display(10,20)

# default arguments
def display(a = 0,b = 0,c = 0):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)

# keyword arguments
def display(b,c,a):
    print(a,b,c)
display(a = 10 , c = 30, b = 20 )

# variable length arguments
def display(*args):
    #print(kargs)
    for val in args:
        print(val)
display(10,20,30,40,45,43,45,2,45,23,1,4,3,0,5,3,2,4,2,'unix')



























