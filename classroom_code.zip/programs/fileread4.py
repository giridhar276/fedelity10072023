
'''

write a program to display the total count of male and female.

Total Male count  : xx
Total Female count: xx

'''

import csv
male = 0
female = 0
with open('adult.csv','r') as fobj:
    header= fobj.readline()
    # convert fobj to csv understandable object
    reader = csv.reader(fobj)
    for line in reader:
        line[9] = line[9].strip()
        if line[9] == 'Male':
            male = male + 1
        elif line[9] == 'Female':
            female = female + 1
            
    print('total male count :', male)
    print('total female count :', female)