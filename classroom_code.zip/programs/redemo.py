



with open('languages.txt','r') as fr:
    for line in fr:
        line = line.strip()
        if 'python' in line or 'pytthon' in line or 'pytttttttthon' in line or 'pyttttttttttthon' in line:
            print(line)
            
            
            
import re            
with open('languages.txt','r') as fr:
    for line in fr:
        line = line.strip()
        if re.search('(python|java)',line):
            print(line)
            
            
            
import re            
with open('languages.txt','r') as fr:
    for line in fr:
        line = line.strip()
        if re.search('(python|unix)',line):
            print(line)
            
            
            
            
import re            
with open('languages.txt','r') as fr:
    for line in fr:
        line = line.strip()
        if re.search('(python',line)   or re.search('unix',line):
            print(line) 
            
            
            
            
import re            
with open('languages.txt','r') as fr:
    for line in fr:
        line = line.strip()
        if re.search('^python',line):
            print(line)
            
            
import re            
with open('languages.txt','r') as fr:
    for line in fr:
        line = line.strip()
        if re.match('python',line):
            print(line)
            
            