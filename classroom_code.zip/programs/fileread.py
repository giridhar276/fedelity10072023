


import fileoperation


myobj1 = fileoperation.FileOperation('business.csv')
myobj1.displayOutput()



myobj1 = fileoperation.FileOperation('languages.txt')
myobj1.displayOutput()