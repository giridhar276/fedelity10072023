# method1
# all the methods will be imported to your program space
import math
print(math.log(1))
print(math.tan(2))
print(math.floor(34.2))

# method2  - importing the library with alias name
import math as m
print(m.log(1))
print(m.tan(2))
print(m.floor(34.2))

# method3 - import required methods only
from math import sin,ceil,cos
print(sin(2))
print(ceil(1))
print(cos(1))

# method4
from math import *
print(sin(2))
print(ceil(1))
print(cos(1))