import pymysql
try:
    #step1
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='Password@1') 
    if conn:
        cursor = conn.cursor()
        #step2
        query = "insert into adultinfo.adult values('{}','{}','{}')".format('Private','PhD','Doctor')
        #query= "insert into adultinfo.adult values('Public','Inter','driver')"
        #step3
        cursor.execute(query)
        #step4
        print(cursor.rowcount,"record inserted")
        #step5
        conn.commit()
        
        query= "select * from adultinfo.adult"
        cursor.execute(query)
        for record in cursor.fetchall():
            worktype = record[0]
            education = record[1]
            occupation = record[2]
            print(worktype,education,occupation)
            print("------")        
        
        
        conn.close()
    else:
        print('connection not successful.. something went wrong')
except pymysql.DataError as err:
    print(err)
except pymysql.DatabaseError as err:
    print(err)
except pymysql.OperationalError as err:
    print(err)    
except (pymysql.IntegrityError,pymysql.InternalError) as err:
    print(err)
except Exception as err:
    print(err)