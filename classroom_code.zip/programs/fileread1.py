#method1
# displaying the file line by line
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
# method2
# reading the file to the list
with open('languages.txt','r') as fobj:
    print(fobj.readlines())
    
with open('languages.txt','r') as fobj:
    for line in fobj.readlines():
        print(line.strip())        
# readthe file using fobj.read()
with open('languages.txt','r') as fobj:
    print(fobj.read())
#method3
# using csv library
import csv
with open('languages.txt','r') as fobj:
    # convert fobj to csv understandable object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)

#method4
# using pandas
import pandas
df = pandas.read_csv('languages.txt')
print(df) 
    
    
