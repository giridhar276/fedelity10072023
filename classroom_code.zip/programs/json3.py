



import json

with open('500.json','r',encoding = 'utf-8') as fr:
    # converting file object to json understandable format
    data = json.load(fr)
    for record in data['feeds']:
        output = list(record.values())
        #print(output)
        for val in output:
            print(val)
        print("--------")