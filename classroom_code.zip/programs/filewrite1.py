


fw = open('languages.txt','a')
fw.write('unix\n')
fw.close()






fobj = open('numberst.txt','w')
for val in range(110,300,2):
    fobj.write(str(val) + "\n")
fobj.close()



