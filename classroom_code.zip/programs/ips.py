

'''

write a program to display the below IP addresses

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
'''




for value in range(1,11):
    ip = "192.168.0.{}"
    print(ip.format(value))
    
   
ip = "198.168.0."
for value in range(1,11):
    finalip =ip + str(value) 
    print(finalip)
    