





book = {"chap1":[10,'UK','Mark'] ,"chap2":[20,'US','Pet']}


print(book)

book['chap1'].append('200pages')
book['chap2'].append('400pages')

print(book)