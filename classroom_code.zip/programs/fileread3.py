

import csv
workclass = set()
with open('adult.csv','r') as fobj:
    header= fobj.readline()
    # convert fobj to csv understandable object
    reader = csv.reader(fobj)
    for line in reader:
        workclass.add(line[1])
    
    # display the output
    for item in workclass:
        item = item.strip()
        print(item)