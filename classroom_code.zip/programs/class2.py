
class Employee:
    def getEmployee(self,name,address):
        self.name= name
        self.address = address
        
    def displayEmployee(self):
        print("Employee name :",self.name)
        print("Address       :",self.address)

#object creation
emp1 = Employee()
emp1.getEmployee('rita','hyd')
emp1.displayEmployee()

    

emp2 = Employee()
emp2.getEmployee('singh','mumbai')
emp2.displayEmployee()


