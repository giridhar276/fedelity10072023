
# traditional way
# single liner function
def display(a,b):
    print(a,b)

display(10,20)


# pythonic style
# lambda
# lambda is the replacment of the single liner function for better performance
#functioname  = lambda variables:expression
display = lambda a,b:a + b

display(10,20)

# example2

square = lambda x : x* x if ( x > 0) else x
square(4)



import matplotlib.pyplot as plt
labels = 'Frogs', 'Hogs', 'Dogs', 'Logs'
sizes = [15, 30, 45, 10]

fig, ax = plt.subplots()
ax.pie(sizes, labels=labels)

