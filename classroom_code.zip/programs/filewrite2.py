
### to create thte file in different path


# traditional way
fw = open('C:\\Users\\Administrator\\Desktop\\output\\languages.txt','a')
fw.write('unix\n')
fw.close()


# r - raw string
fw = open(r'C:\Users\Administrator\Desktop\output\languages.txt','a')
fw.write('unix\n')
fw.close()


fw = open('C:/Users/Administrator/Desktop/output/languages.txt','a')
fw.write('unix\n')
fw.close()
