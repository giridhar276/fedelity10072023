

import csv
with open('adult.csv','r') as fobj:
    # convert fobj to csv understandable object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
        
        
#write a program to display workclass ,education and occupation columns data

import csv
with open('adult.csv','r') as fobj:
    # convert fobj to csv understandable object
    reader = csv.reader(fobj)
    for line in reader:
        print("Workclass :",line[1])
        print("Education :",line[3])
        print("Occupation :",line[6])