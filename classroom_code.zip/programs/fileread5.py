
'''
write a proram to display all the lines in the lower case.

'''


with open('adult.csv','r') as fobj:
    for line in fobj:
        line = line.strip()
        print(line.lower())
        
        
        
import csv
with open('adult.csv','r') as fobj:
    # convert fobj to csv understandable object
    reader = csv.reader(fobj)
    for line in reader:
        #print(line)
        # convert the list to the string with ,
        singleline = ",".join(line)
        singleline = singleline.lower()
        print(singleline)