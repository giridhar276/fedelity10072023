


# creating 10 directories
import os    
for val in range(1,11):
    dirname = "dir" + str(val)
    if not os.path.exists(dirname):
        os.mkdir(dirname)
    else:
        print(dirname,'already exists')
        
        
        
        


for val in range(1,5):
    os.mkdir("dir" + str(val))