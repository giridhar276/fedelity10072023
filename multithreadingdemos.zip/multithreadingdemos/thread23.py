# -*- coding: utf-8 -*-
"""
Explain the usage of threading. local()
"""

