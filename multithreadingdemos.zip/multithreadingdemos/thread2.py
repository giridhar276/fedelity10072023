# program to create a thread which will print 'hello world'
# program to create a thread which will print 'hello world'

import threading
def uf():
    """thread uf function"""
    print("hello world - uf")
    return


def gf():
    """thread uf function"""
    print("hello world  - gf")
    return

threads = []
t1 = threading.Thread(target = uf,args=(1,2,))
t2 = threading.Thread(target = gf)
threads.append(t1)
threads.append(t2)
t1.start()
t2.start()